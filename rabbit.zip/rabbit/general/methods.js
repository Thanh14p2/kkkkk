const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle(' ** [Layer7] Hung DDoS ** ')
	.setDescription("**LAYER 7** \n `HTTP-B�O` \n `HTTP-BROWSER` \n `HTTP-RAW` \n `HTTP-V2` \n `HTTP-FLOOD` \n `HTTP-CF` \n  `HTTP-FLOOD` \n `HTTP-BY` \n `HTTP-RAW` \n**LAYER 4** \n `TCP-KILL` \n `UDP-KILL` \n `Help` \n **Sẽ sớm update thêm Methods**")
	message.channel.send(embed1);
	return;
	}

}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['methods'],
  permLevel: 0
}

exports.help = {
  name: 'methods',
  description: 'Hung#0196',
  usage: 'methods'
}
